package ensinomedio;
import ensinomedio.Aluno.Sexo;

/**
 * Hello world!
 *
 */
public class Escola 
{
    public static void main( String[] args )
    {
        Aluno felipe = new Aluno("felipe", 15, 123456789, "Rua 1, 123", Sexo.MASCULINO);
        System.out.println("Nome: " + felipe.getNome());
        System.out.println("Idade: " + felipe.getIdade());
        System.out.println("CPF: " + felipe.getCpf());
        System.out.println("Endereço: " + felipe.getEndereco());
        System.out.println("Sexo: " + felipe.getSexo());
        
        System.out.println(" ");
        Aluno maria = new Aluno();
        System.out.println(" ");
        
        maria.setNome("Maria");
        maria.setIdade(16);
        maria.setCpf(987654321);
        maria.setEndereco("Rua 2, 456");
        maria.setSexo(Sexo.FEMININO);
        System.out.println("Nome: " + maria.getNome());
        System.out.println("Idade: " + maria.getIdade());
        System.out.println("CPF: " + maria.getCpf());
        System.out.println("Endereço: " + maria.getEndereco());
        System.out.println("Sexo: " + maria.getSexo());

    }
}
