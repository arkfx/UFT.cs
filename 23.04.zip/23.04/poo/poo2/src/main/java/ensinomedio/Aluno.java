package ensinomedio;

public class Aluno {

    private String nome;
    private int idade;
    private int cpf;
    private String endereco;
    private Sexo sexo;
    public enum Sexo {
        MASCULINO, FEMININO
    }   
    
    public Aluno(String nome, int idade, int cpf, String endereco, Sexo sexo) {
        this.nome = nome;
        this.idade = idade;
        this.cpf = cpf;
        this.endereco = endereco;
        this.sexo = sexo;
    }

    public Aluno(){
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }
    
} 
