package lanchonete.atendimento.cozinha;
import lanchonete.atendimento.Atendente;

/**
 * Hello world!
 *
 */
public class Cozinheiro 
{
    public void adicionarLancheNoBalcao() {
        System.out.println("adicionando lanche no balcão: ");
    }

    public void adicionarSucoNoBalcao() {
        System.out.println("adicionando suco no balcão: ");
    }

    public void adicionarComboNoBalcao() {
        adicionarLancheNoBalcao();
        adicionarSucoNoBalcao();
    }

    public void prepararLanche() {
        System.out.println("preparando lanche: ");
    }

    public void prepararVitamina()  {
        System.out.println("preparando vitamina:");
    }

    public void prepararCombo() {
        prepararLanche();
        prepararVitamina();
    }

    public void selecionarIngredientesLanche() {
        System.out.println("selecionando ingredientes do lanche: ");
    }

    public void selecionarIngredientesVitamina() {
        System.out.println("selecionando ingredientes da vitamina: ");
    }

    public void lavarIngredientes() {
        System.out.println("lavando ingredientes: ");
    }

    public void baterVitaminaNoLiquidificador() {
        System.out.println("batendo vitamina no liquidificador: ");
    }

    public void fritarIngredientesLanche() {
        System.out.println("fritando ingredientes do lanche: ");
    }

    public void pedirParaTrocarGás(Atendente meuAmigo) {
        meuAmigo.trocarGas();
    }

    public void pedirParaTrocarGás(Almoxerife almorxerife){
        almorxerife.trocarGas();
    }

    public void pedirIngredientes(Almoxerife almoxerife) {
        almoxerife.entregarIngredientes();
    }


}
