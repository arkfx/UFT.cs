package lanchonete.Cliente;

public class Cliente {
    public void escolherLanche() {
        System.out.println("Cliente escolhendo lanche: ");
    }

    public void fazerPedido() {
        System.out.println("Cliente fazendo pedido: ");
    }

    public void pagarConta() {
        System.out.println("Cliente pagando conta: ");
    }

    public void consultarSaldoAplicativo() {
        System.out.println("Cliente consultando saldo no aplicativo: ");
    }

    public void pegarPedidoNoBalcao() {
        System.out.println("Cliente pegando pedido no balcão: ");
    }

}
