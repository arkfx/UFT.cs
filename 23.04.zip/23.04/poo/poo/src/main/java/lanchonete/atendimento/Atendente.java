package lanchonete.atendimento;

public class Atendente {
    public void servindoMesa() {
        System.out.println("Atendente servindo mesa: ");
    }

    public void pegarLancheCozinha() {
        System.out.println("Atendente pegando lanche na cozinha: ");
    }

    public void receberPagamento() {
        System.out.println("Atendente recebendo pagamento: ");
    }

    public void trocarGas() {
        System.out.println("Atendente trocando gas: ");
    }

    public void pegarPedidoNoBalcao() {
        System.out.println("Atendente pegando pedido no balcão: ");
    }
}
