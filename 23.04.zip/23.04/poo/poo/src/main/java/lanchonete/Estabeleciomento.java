package lanchonete;
import lanchonete.Cliente.Cliente;
import lanchonete.atendimento.Atendente;
import lanchonete.atendimento.cozinha.Almoxerife;
import lanchonete.atendimento.cozinha.Cozinheiro;

public class Estabeleciomento {
    public static void main(String[] args) {
        Cozinheiro cozinheiro1 = new Cozinheiro();
        Almoxerife almoxerife1 = new Almoxerife();
        Atendente atendente1 = new Atendente();
        Cliente cliente1 = new Cliente();
        
        System.out.println('\n');
        System.out.println("COZINHEIRO: ");
        System.out.println('\n');
        
        //todas as 14 funções do cozinheiro
        cozinheiro1.adicionarLancheNoBalcao();
        cozinheiro1.adicionarSucoNoBalcao();
        cozinheiro1.adicionarComboNoBalcao();
        cozinheiro1.prepararLanche();
        cozinheiro1.prepararVitamina();
        cozinheiro1.prepararCombo();
        cozinheiro1.selecionarIngredientesLanche();
        cozinheiro1.selecionarIngredientesVitamina();
        cozinheiro1.lavarIngredientes();
        cozinheiro1.baterVitaminaNoLiquidificador();
        cozinheiro1.fritarIngredientesLanche();
        cozinheiro1.pedirParaTrocarGás(atendente1);
        cozinheiro1.pedirParaTrocarGás(almoxerife1);
        cozinheiro1.pedirIngredientes(almoxerife1);



        System.out.println('\n');
        System.out.println("ALMOXERIFE: ");
        System.out.println('\n');
        
        //todas as 4 funções do almoxerife
        almoxerife1.controlarEntrada();
        almoxerife1.controlarSaida();
        almoxerife1.entregarIngredientes();
        almoxerife1.trocarGas();


        
        System.out.println('\n');
        System.out.println("ATENDENTE: ");
        System.out.println('\n');
        
        //todas as 5 funções do atendente
        atendente1.servindoMesa();
        atendente1.pegarLancheCozinha();
        atendente1.receberPagamento();
        atendente1.trocarGas();
        atendente1.pegarPedidoNoBalcao();


        
        System.out.println('\n');
        System.out.println("CLIENTE: ");
        System.out.println('\n');
        
        //todas as 5 funções do cliente
        cliente1.escolherLanche();
        cliente1.fazerPedido();
        cliente1.pagarConta();
        cliente1.consultarSaldoAplicativo();
        cliente1.pegarPedidoNoBalcao();


    }

        
    
    
}
