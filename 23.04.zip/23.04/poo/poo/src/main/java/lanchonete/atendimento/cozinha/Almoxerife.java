package lanchonete.atendimento.cozinha;

public class Almoxerife {
    public void controlarEntrada() {
        System.out.println("Almoxerife scontrolando entrada dos itens: ");
    }

    public void controlarSaida() {
        System.out.println("Almoxerife controlando saída dos itens: ");
    }

    
    public void entregarIngredientes() {
        System.out.println("Almoxerife entregando ingredientes:");
    }

    public void trocarGas() {
        System.out.println("Almoxerife trocando gas: ");
    }
}
