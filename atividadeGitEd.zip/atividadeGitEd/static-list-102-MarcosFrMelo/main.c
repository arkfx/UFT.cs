#include<stdio.h>
#include "TStaticList.h"

int main(){
  TStaticList* lists[3] = {
    TStaticList_create(), 
    TStaticList_create(), 
    TStaticList_create()
  };

  char op;
  int value;
  int index;
  int line=1;
  do{
    scanf("%c %d %d\n", &op, &value, &index);
    printf("line=%d op=%c, value=%d, index=%d\n",line++, op, value, index);
    if(value == 0 && index ==0 && op == '0')
      break;
    switch (op) {
      case 'i': 
        if(TStaticList_insert(lists[index], value))
          printf("success\n");
        else
          printf("fail\n");
        break;
      case 'p':
        TStaticList_print(lists[index]);
        break;
    }
  }while(1);

  return 0;

  return 0;
}