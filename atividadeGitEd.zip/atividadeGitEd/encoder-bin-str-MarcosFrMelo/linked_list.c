#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "linked_list.h"

struct _no{
    int quantidadeBinarios;
    char binario;
    No *proximo;
};

struct _linked_list{
    No *inicio;
    int tamanho;
};

LinkedList * LinkedList_create(){
    LinkedList *nova = malloc(sizeof(LinkedList));
    if (nova != NULL) {
        nova->inicio = NULL;
        nova->tamanho = 0;
    }
    return nova;
}

No * No_create(char binario, int quantidadeBinarios){
No *nova = malloc(sizeof(No));
  if (nova) {
    nova->binario = binario;
    nova->quantidadeBinarios = quantidadeBinarios;
    nova->proximo = NULL;
  }
  return nova;
}

bool LinkedList_insert_end(LinkedList *list, char binario, int quantidadeBinarios) {
  No *novo = No_create(binario, quantidadeBinarios);
  if (novo == NULL)
    return false;
  if (list->inicio == NULL){
    list->inicio = novo;
    list->tamanho++;
  }
  else {
    No *aux = list->inicio;
    list->tamanho++;
    while (aux->proximo != NULL)
      aux = aux->proximo;
    aux->proximo = novo;
  }
  return true;
}

void separarBinarios(LinkedList *lista, char *binario){
    char atual = binario[0];
    int cont = 1;
    for (int i = 1; i < strlen(binario); i++)
    {
        if (binario[i] == atual)
            cont++;
        else{
            LinkedList_insert_end(lista, atual, cont); 
            cont = 1;
            lista->tamanho++;
        }
        atual = binario[i];
    }
}

void printarLista(LinkedList *lista){
    No *aux = lista->inicio;
    printf("%d\n", lista->tamanho);
    while (aux->proximo != NULL)
    {
        printf("%d %c\n", aux->quantidadeBinarios, aux->binario);
        aux = aux->proximo;
    }
    printf("%d %c\n", aux->quantidadeBinarios, aux->binario);
}