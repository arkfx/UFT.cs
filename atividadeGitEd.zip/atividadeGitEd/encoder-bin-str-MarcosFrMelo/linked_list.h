#ifndef LINKED_LIST_H
#define LINKED_LIST_H

    #include <stdbool.h>

    typedef struct _no No;
    typedef struct _linked_list LinkedList;
    
    /**
     * @brief criar a lista
     * @return ponteiro para o lista criada
    */
    LinkedList * LinkedList_create();

    /**
     * @brief criar um nó
     * @param int - valor do nó a ser inserido no nó
     * @return ponteiro para o nó criado
    */
    No * No_create(char, int);

    /**
     * @brief inserir um nó no final da lista
     * @param LinkedList * - lista
     * @param int - valor do nó
     * @return true caso der certo de inserir, false se não dê certo
    */
    bool LinkedList_insert_end(LinkedList *, char, int);

    void separarBinarios(LinkedList *, char *);

    void printarLista(LinkedList *);

#endif