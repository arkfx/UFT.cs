#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linked_list.h"

int main(){

  char binario[10001];
  scanf("%s", &binario);
  LinkedList *lista = LinkedList_create();
  char atual = binario[0];
  int cont = 1;
  for (int i = 1; i < strlen(binario); i++)
  {
    if (binario[i] == atual)
      cont++;
    else{
      LinkedList_insert_end(lista, atual, cont); 
      cont = 1;
    }
    atual = binario[i];
  }
  LinkedList_insert_end(lista, atual, cont);
  printarLista(lista);
  return 0;
}