#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "linked_list.h"

void printarListaDesembaralhada(LinkedList *list);

struct _no{
    unsigned int id, id_prox;
    float valor;
    No *proximo;
};

struct _linked_list{
    No *inicio;
};

LinkedList * LinkedList_create(){
    LinkedList *nova = malloc(sizeof(LinkedList));
    if (nova != NULL) {
        nova->inicio = NULL;
    }
    return nova;
}

No * No_create(unsigned int id, unsigned int id_prox, float valor){
    No *nova = malloc(sizeof(No));
    if (nova) {
      nova->id = id;
      nova->valor = valor;
      nova->id_prox = id_prox;
      nova->proximo = NULL;
    }
    return nova;
}

bool LinkedList_insert_end(LinkedList *list, unsigned int valor, unsigned int id_prox, float valor_prox) {
  No *novo = No_create(valor, id_prox, valor_prox);
  if (novo == NULL)
    return false;
  if (list->inicio == NULL)
    list->inicio = novo;
  else {
    No *aux = list->inicio;
    while (aux->proximo != NULL)
      aux = aux->proximo;
    aux->proximo = novo;
  }
  return true;
}

void printarListaDesembaralhada(LinkedList *list) {
  No *aux = list->inicio;
  No *aux2 = list->inicio;
  do
  {
    if (aux2->id == aux->id_prox)
    {
      printf("%.1f,", aux->valor);
      aux = aux2;
      aux2 = list->inicio;
    }
    else
    {
      aux2 = aux2->proximo;
    }
  } while (aux->id_prox != 0);
  printf("%.1f,", aux->valor);
}

void LinkedList_destroy(LinkedList *list){
    No *aux = list->inicio;
    while (aux != NULL) {
        No *temp = aux->proximo;
        free(aux);
        aux = temp;
    }
    free(list);
}