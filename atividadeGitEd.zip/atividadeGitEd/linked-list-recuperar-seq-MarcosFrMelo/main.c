#include<stdio.h>
#include"linked_list.h"

int main(){
    LinkedList *lista = LinkedList_create();
    
    unsigned int id, id_prox;
    float valor;

    while(1){
        scanf("%u %f %u", &id, &valor, &id_prox);    
        LinkedList_insert_end(lista, id, id_prox, valor);
        if(id==0) break;
    }
    printarListaDesembaralhada(lista);
    LinkedList_destroy(lista);
    return 0;
}