#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "linked_list.h"

struct _no{
    int info;
    No *proximo;
};

struct _linked_list{
    No *inicio;
};

LinkedList * LinkedList_create(){
    LinkedList *nova = malloc(sizeof(LinkedList));
    if (nova != NULL) {
        nova->inicio = NULL;
    }
    return nova;
}

No * No_create(int informacao){
No *nova = malloc(sizeof(No));
  if (nova) {
    nova->info = informacao;
    nova->proximo = NULL;
  }
  return nova;
}

bool LinkedList_insert_end(LinkedList *list, int valor) {
  No *novo = No_create(valor);
  if (novo == NULL)
    return false;
  if (list->inicio == NULL)
    list->inicio = novo;
  else {
    No *aux = list->inicio;
    while (aux->proximo != NULL)
      aux = aux->proximo;
    aux->proximo = novo;
  }
  return true;
}

int sukunaDesmantelar(int valor){
    return valor % 100;
}

int sukunaCorte(int valor){
    return valor / 100;
}

int verificarParImpar(int valor){
    return (valor % 2) == 0? valor/2: valor+1;
}

void printarLista(LinkedList *list){
    
  if (list->inicio == NULL)
      return;
  No *aux = list->inicio;
  do
  {
    if (aux->proximo != NULL)
      printf("%d->", aux->info);
    aux = aux->proximo;
  } while (aux->proximo != NULL);
  printf("%d\n", aux->info);
}

int vazioRoxo(int a, int b){
    int fator = (b>=10)? 100:10;
    return (a*fator) + b;
}
