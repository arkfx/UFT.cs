#include <stdio.h>
#include "linked_list.h"

int main(){
    
    LinkedList *list = LinkedList_create();
    int n, a, b;

    scanf("%d", &n);
    LinkedList_insert_end(list, n);
    do{
        a = sukunaCorte(n); //divisao
        b = sukunaDesmantelar(n);   //resto

        a = verificarParImpar(a);
        b = verificarParImpar(b);

        n = vazioRoxo(a, b);    //num final, junção dos dois numeros
        LinkedList_insert_end(list, n);
    } while (n >= 10);
    printarLista(list);
}