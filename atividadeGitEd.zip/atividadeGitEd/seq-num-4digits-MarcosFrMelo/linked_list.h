#ifndef LINKED_LIST_H
#define LINKED_LIST_H

    #include <stdbool.h>

    typedef struct _no No;
    typedef struct _linked_list LinkedList;
    
    /**
     * @brief criar a lista
    */
    LinkedList * LinkedList_create();

    /**
     * @brief criar um nó
    */
    No * No_create(int);

    /**
     * @brief inserir um nó no final da lista
     * @param LinkedList * - lista
     * @param int - valor do nó
    */
    bool LinkedList_insert_end(LinkedList *, int);

    /**
     * @brief dividir um valor e coletar o resto
     * @param valor a ser dividio e coletado o resto
     * @return o resto da divisão
    */
    int sukunaDesmantelar(int);

    /**
     * @brief dividir um valor e coletar o quociente
     * @param valor a ser dividio e coletado o quociente
     * @return o quociente da divisão
    */
    int sukunaCorte(int);

    /**
     * @brief verificar se um número é par ou ímpar
     * @param valor a ser verificado
     * @return o valor dividido por 2 se for par, somado 1 se for ímpar
    */
    int verificarParImpar(int);

    /**
     * @brief printar todos os valores da lista
     * @param LinkedList * - lista
    */
    void printarLista(LinkedList *);

    /**
     * @brief juntar dois valores
     * @param valor a ser juntado
     * @return o valor juntado
    */
    int vazioRoxo(int, int);



#endif