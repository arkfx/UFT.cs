#include<stdio.h>

int main(){
  int n, a, b;
  scanf("%d", &n);
  while(n-->0){
    scanf("%d %d", &a, &b);
    printf("%d\n", a);
  }
  return 0;
}