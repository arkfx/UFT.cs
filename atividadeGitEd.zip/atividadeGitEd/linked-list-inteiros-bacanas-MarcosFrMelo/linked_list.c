#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "linked_list.h"

struct _no{
    int info;
    No *proximo;
};

struct _linked_list{
    No *inicio;
};

LinkedList * LinkedList_create(){
    LinkedList *nova = malloc(sizeof(LinkedList));
    if (nova != NULL) {
        nova->inicio = NULL;
    }
    return nova;
}

No * No_create(int informacao){
    No *nova = malloc(sizeof(No));
    if (nova) {
        nova->info = informacao;
        nova->proximo = NULL;
    }
    return nova;
}

bool LinkedList_insert_end(LinkedList *list, int valor) {
  No *novo = No_create(valor);
  if (novo == NULL)
    return false;
  if (list->inicio == NULL)
    list->inicio = novo;
  else {
    No *aux = list->inicio;
    while (aux->proximo != NULL)
      aux = aux->proximo;
    aux->proximo = novo;
  }
  return true;
}

bool LinkedList_insert_begin(LinkedList * lista, int valor){
  
  No *novo = No_create(valor);
  if (novo == NULL)
    return false;
  if (lista->inicio == NULL)
    lista->inicio = novo;
  else{
    novo->proximo = lista->inicio;
    lista->inicio = novo;
  }
  return true;
  
}

void dividindoNumero(LinkedList *listaDividida, int numero){
  int numeroDividido;
  LinkedList_insert_begin(listaDividida, numero);
  do{
    numeroDividido = numero / 10;
    numero = numero % 10; 
    LinkedList_insert_begin(listaDividida, numero);
    numero = numeroDividido;
  }while (numero > 9);
  LinkedList_insert_begin(listaDividida, numero);
}

int vazioRoxo(LinkedList *listaDividida){
  int soma = 0;
  No *aux = listaDividida->inicio;
  do{
    soma = soma + (aux->info*aux->info); 
    aux = aux->proximo;
  }while (aux->proximo != NULL);
  return soma;
}

void printarLista(LinkedList *lista){
  if (lista->inicio == NULL)
      return;
  No *aux = lista->inicio;
  do
  {
    printf("%d, ", aux->info);
    aux = aux->proximo;
  } while (aux->proximo != NULL);
    printf("%d, ", aux->info);
  if (aux->info != 1)
    printf("\nnon-bacana\n");
  else
    printf("\nbacana\n");
}

void LinkedList_destroy(LinkedList *list){
  No *aux = list->inicio;
  No *aux2;
  while (aux != NULL){
    aux2 = aux->proximo;
    free(aux);
    aux = aux2;
  }
  free(list);
}