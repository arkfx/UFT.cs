#ifndef LINKED_LIST_H
#define LINKED_LIST_H

    #include <stdbool.h>

    typedef struct _no No;
    typedef struct _linked_list LinkedList;
    
    /**
     * @brief criar a lista
     * @return ponteiro para o lista criada
    */
    LinkedList * LinkedList_create();

    /**
     * @brief criar um nó
     * @param int - valor do nó a ser inserido no nó
     * @return ponteiro para o nó criado
    */
    No * No_create(int);

    /**
     * @brief inserir um nó no final da lista
     * @param LinkedList * - lista
     * @param int - valor do nó
     * @return true caso der certo de inserir, false se não dê certo
    */
    bool LinkedList_insert_end(LinkedList *, int);

    /**
     * @brief inserir um nó no inicio da lista
     * @param LinkedList * - lista
     * @param int - valor do nó
     * @return true caso der certo de inserir, false se não dê certo
    */
    bool LinkedList_insert_begin(LinkedList *, int);

    /**
     * @brief ira pegar um numero e dividir todos os caracteres dele e inserir na lista
     * @param LinkedList * - lista que ira receber os numeros divididos
     * @param int - numero a ser dividido
    */
    void dividindoNumero(LinkedList *, int);

    /**
     * @brief ira realizar a multiplicação ao quadrado e somar todos os valores da lista
     * @param LinkedList * - lista dos numeros divididos
     * @return int - soma dos valores
    */
    int vazioRoxo(LinkedList *);

    /**
     * @brief ira printar a lista
     * @param LinkedList * - lista a ser printada
    */
    void printarLista(LinkedList *);

    /**
     * @brief destruir a lista
     * @param LinkedList * - lista a ser destruida
    */
    void LinkedList_destroy(LinkedList *);
#endif