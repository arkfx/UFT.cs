#include <stdio.h>
#include "linked_list.h"

int main(){
    LinkedList *lista = LinkedList_create();
    int soma, numero;
    scanf("%d", &numero);
    LinkedList_insert_end(lista, numero);
    while(numero > 9){
        LinkedList *listaDividida = LinkedList_create();
        dividindoNumero(listaDividida, numero);
        soma = vazioRoxo(listaDividida);
        LinkedList_insert_end(lista, soma);
        numero = soma;
        LinkedList_destroy(listaDividida);
    }
    printarLista(lista);
    LinkedList_destroy(lista);
}